@extends('layouts.auth')
@section('title', 'Login')

@section('content')
<div class="w-full max-w-md mx-auto px-8">
    <h2 class="text-3xl font-bold text-gray-900 mb-2">Masuk ke ReTalent</h2>
    <p class="text-gray-500 text-sm mb-8">Silakan masukkan kredensial Anda untuk mengakses sistem.</p>

    <form action="{{ route('login.process') }}" method="POST" class="space-y-6">
    @csrf
    
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">NIP (Nomor Induk Pegawai) atau Email</label>
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i data-feather="user" class="w-5 h-5 text-gray-400"></i>
                </div>
                <input type="text" name="email" value="{{ old('email') }}" class="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0d2a7a] focus:border-transparent text-sm" placeholder="Masukkan NIP atau Email Anda" required>
            </div>
            @error('email')
                <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i data-feather="lock" class="w-5 h-5 text-gray-400"></i>
                </div>
                <input type="password" name="password" class="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0d2a7a] focus:border-transparent text-sm" placeholder="Masukkan Kata Sandi" required>
            </div>
            @error('password')
                <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p>
            @enderror
        </div>

        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <input id="remember" type="checkbox" class="h-4 w-4 text-[#0d2a7a] focus:ring-[#0d2a7a] border-gray-300 rounded">
                <label for="remember" class="ml-2 block text-sm text-gray-700">Ingat Saya</label>
            </div>
            <div class="text-sm">
                <a href="{{ route('password.reset') }}" class="font-medium text-[#0d2a7a] hover:text-blue-800">Lupa Password?</a>
            </div>
        </div>

        <button type="submit" class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-[#0d2a7a] hover:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#0d2a7a]">
            Masuk
        </button>

        <div class="bg-blue-50 p-4 rounded-lg flex items-start space-x-3 border border-blue-100">
            <i data-feather="info" class="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5"></i>
            <p class="text-xs text-blue-800 leading-relaxed">
                Sistem ini memantau seluruh aktivitas login untuk keamanan data perusahaan. Pastikan Anda keluar setelah selesai bertugas.
            </p>
        </div>
    </form>
</div>
@endsection
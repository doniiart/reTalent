<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ReTalent - HRIS Enterprise</title>
    @vite('resources/css/app.css')
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body class="bg-gray-50 flex h-screen font-sans text-gray-800">

    <aside class="w-64 bg-[#1e3a8a] text-white flex flex-col h-full shadow-lg">
        <div class="p-6 flex items-center space-x-3">
            <div class="bg-white text-[#1e3a8a] p-1 rounded font-bold text-xl">
                <i data-feather="box"></i>
            </div>
            <div>
                <h1 class="text-xl font-bold tracking-wide">ReTalent</h1>
                <p class="text-xs text-blue-200">HRIS Enterprise</p>
            </div>
        </div>

        <nav class="flex-1 px-4 py-4 space-y-2">
            <a href="{{ route('user.dashboard') }}" 
               class="flex items-center space-x-3 px-4 py-3 rounded-lg transition {{ request()->routeIs('user.dashboard') ? 'bg-blue-700/50 text-white border-l-4 border-blue-400 font-medium' : 'text-blue-200 hover:bg-blue-800 hover:text-white' }}">
                <i data-feather="grid"></i>
                <span>Dashboard</span>
            </a>
            
            <a href="{{ route('user.employees') }}" 
               class="flex items-center space-x-3 px-4 py-3 rounded-lg transition {{ request()->routeIs('user.employees') ? 'bg-blue-700/50 text-white border-l-4 border-blue-400 font-medium' : 'text-blue-200 hover:bg-blue-800 hover:text-white' }}">
                <i data-feather="users"></i>
                <span>Rekan Kerja</span>
            </a>
            
            <a href="{{ route('user.payroll') }}" 
               class="flex items-center space-x-3 px-4 py-3 rounded-lg transition {{ request()->routeIs('user.payroll') ? 'bg-blue-700/50 text-white border-l-4 border-blue-400 font-medium' : 'text-blue-200 hover:bg-blue-800 hover:text-white' }}">
                <i data-feather="dollar-sign"></i>
                <span>Penggajian</span>
            </a>
            
            <a href="{{ route('user.attendance') }}" 
               class="flex items-center space-x-3 px-4 py-3 rounded-lg transition {{ request()->routeIs('user.attendance') ? 'bg-blue-700/50 text-white border-l-4 border-blue-400 font-medium' : 'text-blue-200 hover:bg-blue-800 hover:text-white' }}">
                <i data-feather="calendar"></i>
                <span>Kehadiran</span>
            </a>

            <a href="{{ route('user.leave') }}" 
               class="flex items-center space-x-3 px-4 py-3 rounded-lg transition {{ request()->routeIs('user.leave') || request()->routeIs('user.leave-apply') ? 'bg-blue-700/50 text-white border-l-4 border-blue-400 font-medium' : 'text-blue-200 hover:bg-blue-800 hover:text-white' }}">
                <i data-feather="briefcase"></i>
                <span>Cuti</span>
            </a>
            
            <a href="{{ route('user.settings') }}" 
               class="flex items-center space-x-3 px-4 py-3 rounded-lg transition {{ request()->routeIs('user.settings') ? 'bg-blue-700/50 text-white border-l-4 border-blue-400 font-medium' : 'text-blue-200 hover:bg-blue-800 hover:text-white' }}">
                <i data-feather="settings"></i>
                <span>Pengaturan</span>
            </a>
        </nav>

        <div class="p-4 border-t border-blue-800">
            <a href="#" class="flex items-center space-x-3 text-blue-200 hover:text-white mb-3">
                <i data-feather="help-circle"></i>
                <span>Bantuan</span>
            </a>
            <form method="POST" action="{{ route('logout') }}">                
                @csrf
                <button type="submit" class="flex items-center space-x-3 text-red-300 hover:text-white w-full">
                    <i data-feather="log-out"></i>
                    <span>Keluar</span>
                </button>
            </form>
        </div>
    </aside>

    <main class="flex-1 flex flex-col overflow-hidden">
        <header class="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-8">
            <div class="w-1/3">
                <div class="relative">
                    <i data-feather="search" class="absolute left-3 top-2.5 text-gray-400 w-4 h-4"></i>
                    <input type="text" placeholder="Cari data atau laporan..." class="w-full bg-gray-50 border border-gray-200 text-sm rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:border-blue-500">
                </div>
            </div>
            <div class="flex items-center space-x-6">
                <button class="text-gray-400 hover:text-gray-600"><i data-feather="bell"></i></button>
                <div class="flex items-center space-x-3 border-l pl-6 border-gray-200">
                    <div class="text-right">
                        <span class="block font-semibold text-gray-800">{{ auth()->user()->name }}</span>
                        <span class="block text-xs text-gray-500 uppercase">{{ auth()->user()->jabatan ?? 'Karyawan' }}</span>
                    </div>
                    <img src="https://ui-avatars.com/api/?name=Ahmad+Ridwan&background=eff6ff&color=1e3a8a" alt="Profile" class="w-10 h-10 rounded-full">
                </div>
            </div>
        </header>

        <div class="flex-1 overflow-auto p-8">
            @yield('content')
        </div>
    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>
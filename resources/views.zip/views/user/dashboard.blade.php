@extends('layouts.app')

@section('content')
    <div class="flex justify-between items-end mb-8">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Dashboard Karyawan</h2>
            <p class="text-gray-600">Selamat datang kembali, {{ auth()->user()->name }}. Berikut ringkasan aktivitas Anda hari ini.</p>
        </div>
        <div class="flex space-x-3">
            <button class="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg text-sm font-medium border border-gray-200">
                <i data-feather="calendar" class="w-4 h-4 inline mr-2"></i> 30 Desember 2026
            </button>
            <a href="{{ route('user.leave') }}" class="bg-[#1e3a8a] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-800 transition">
                + Ajukan Cuti
            </a>
        </div>
    </div>

    <div class="grid grid-cols-3 gap-6 mb-8">
        <div class="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between">
            <div class="flex justify-between items-start">
                <p class="text-gray-500 text-sm font-medium">Sisa Cuti Tahunan</p>
                <div class="bg-blue-50 text-blue-600 p-2 rounded-lg"><i data-feather="wind" class="w-5 h-5"></i></div>
            </div>
            <div class="mt-4">
                <h3 class="text-4xl font-bold text-gray-800">12 <span class="text-lg text-gray-500 font-normal">Hari</span></h3>
                <p class="text-green-500 text-sm mt-2 flex items-center">
                    <i data-feather="trending-up" class="w-4 h-4 mr-1"></i> Tersedia hingga Des 2026
                </p>
            </div>
        </div>

        <div class="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
    <div class="flex justify-between items-start mb-4">
        <h4 class="text-sm font-semibold text-gray-500">Kehadiran Bulan Ini</h4>
        <div class="p-2 bg-blue-50 text-blue-600 rounded-lg">
            <i data-feather="check-circle" class="w-4 h-4"></i>
        </div>
    </div>
    
    <h3 class="text-3xl font-bold text-gray-800">
        {{ number_format($persentaseKehadiran, 1) }}<span class="text-lg text-gray-500 font-normal">%</span>
    </h3>
    
    <p class="text-sm text-gray-500 mt-2 flex items-center">
        <i data-feather="clock" class="w-4 h-4 mr-1"></i>
        {{ $kehadiranBulanIni }}/{{ $totalHariKerja }} Hari Kerja
    </p>
</div>

                <div class="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <div class="flex justify-between items-start mb-4">
                <h4 class="text-sm font-semibold text-gray-500">Slip Gaji Terbaru</h4>
                <div class="p-2 bg-gray-50 text-gray-600 rounded-lg">
                    <i data-feather="file-text" class="w-4 h-4"></i>
                </div>
            </div>
            
            <h3 class="text-xl font-bold text-gray-800 mt-2">
                @if($slipGajiTerbaru)
                    {{ \Carbon\Carbon::parse($slipGajiTerbaru->created_at)->translatedFormat('F Y') }}
                @else
                    Belum ada slip
                @endif
            </h3>
            
            <a href="{{ route('user.payroll') }}" class="text-sm text-blue-600 hover:underline mt-2 inline-block">Lihat Rincian &rarr;</a>
        </div>
    </div>
@endsection